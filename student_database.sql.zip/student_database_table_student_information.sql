
-- --------------------------------------------------------

--
-- Table structure for table `student_information`
--

DROP TABLE IF EXISTS `student_information`;
CREATE TABLE IF NOT EXISTS `student_information` (
  `ID` varchar(10) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `first` text,
  `middle` text,
  `last` text,
  `address` varchar(140) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `country` text,
  `city` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `zip` varchar(10) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `major` varchar(70) DEFAULT NULL,
  `isAdmin` tinyint(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `ID` (`ID`),
  UNIQUE KEY `username` (`username`),
  KEY `major` (`major`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_information`
--

INSERT INTO `student_information` (`ID`, `username`, `first`, `middle`, `last`, `address`, `phone`, `country`, `city`, `state`, `zip`, `birthdate`, `major`, `isAdmin`) VALUES
('6055411', 'J.Benavides', 'Jeriel', 'Manuel', 'Benavides', 'Somewhere', '+50584390546', 'Nicaragua', 'Estelí', 'Estelí', '31000', '1997-02-25', 'Software Engineering', 0),
('00000', 'Admin', 'Admin', 'Admin', 'Admin', 'Admin', '00000', 'Admin', 'Admin', 'Admin', '00000', '1990-01-01', 'Software Engineering', 1);
