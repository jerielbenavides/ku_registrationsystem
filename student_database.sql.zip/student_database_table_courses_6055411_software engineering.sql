
-- --------------------------------------------------------

--
-- Table structure for table `courses_6055411_software engineering`
--

DROP TABLE IF EXISTS `courses_6055411_software engineering`;
CREATE TABLE IF NOT EXISTS `courses_6055411_software engineering` (
  `coursecode` varchar(10) DEFAULT NULL,
  `coursename` varchar(75) NOT NULL,
  `taken` int(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `coursecode` (`coursecode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses_6055411_software engineering`
--

INSERT INTO `courses_6055411_software engineering` (`coursecode`, `coursename`, `taken`) VALUES
('COP1800C', 'Java Programming I', 0),
('COP1805C', 'Java Programming II', 0),
('COP2360C', 'C# (Sharp) Programming I ', 0),
('CTS1305C', 'Essentials of Networking', 1),
('COT1405', 'Introduction to Algorithms', 0),
('CEN2010', 'Software Engineering I', 0),
('CTS2106C', 'Multi-User Operating Systems ', 1),
('CDA2100', 'Computer Architecture', 1),
('CEN2721', 'Human Computer Interface Design', 1),
('CEN2027', 'Software Maintenance And Evolution', 0),
('COT2104', 'Discrete Mathematics and Probability', 0),
('COP2843C', 'Web Systems ', 0),
('AMH1020', 'American History Since 1877', 1),
('PSY1012', 'Introduction to Psychology', 1),
('SPC1017', 'Speech', 0),
('CGS1000C', 'Introduction to Computers', 0),
('ENC1101', 'English Composition I', 0),
('ENC2102', 'English Composition II', 0),
('FRE1010', 'Freshman Seminar', 1),
('MAC2105', 'College Algebra', 0),
('STA2023', 'Statistics', 1),
('PHIL2050', 'Philosophy of the Human Person', 0),
('COP3610', 'Operating Systems', 1),
('CEN4230', 'Domain Specific Languages', 0),
('COT3205', 'Theory of Computation', 0),
('COP3650', 'Mobile Application Development', 1),
('CEN3011', 'Software Engineering II ', 0),
('CEN3064', 'Software Design', 0),
('CEN3410', 'Software Testing', 1),
('ISM4212', 'Database Management Systems ', 1),
('COP4620', 'Compiler Construction', 1),
('CDA4125', 'Concepts of Parallel and Distributed Processing', 0),
('MAN4583', 'Project Management', 1),
('CEN4086', 'Cloud & Internet Computing', 1),
('CEN3016', 'Specifications of Software Systems ', 0),
('STA3163', 'Intermediate Statistics', 0),
('ENC3213', 'Professional Writing', 0),
('CGS3300', 'Management Information Systems', 0);
