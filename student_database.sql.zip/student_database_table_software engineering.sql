
-- --------------------------------------------------------

--
-- Table structure for table `software engineering`
--

DROP TABLE IF EXISTS `software engineering`;
CREATE TABLE IF NOT EXISTS `software engineering` (
  `credits` tinyint(2) DEFAULT NULL,
  `coursename` varchar(75) DEFAULT NULL,
  `coursecode` varchar(15) NOT NULL,
  PRIMARY KEY (`coursecode`),
  UNIQUE KEY `coursecode` (`coursecode`),
  UNIQUE KEY `coursename` (`coursename`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='All courses for Software Engineering';

--
-- Dumping data for table `software engineering`
--

INSERT INTO `software engineering` (`credits`, `coursename`, `coursecode`) VALUES
(3, 'American History Since 1877', 'AMH1020'),
(4, 'Computer Architecture', 'CDA2100'),
(3, 'Concepts of Parallel and Distributed Processing', 'CDA4125'),
(4, 'Software Engineering I', 'CEN2010'),
(4, 'Software Maintenance And Evolution', 'CEN2027'),
(4, 'Human Computer Interface Design', 'CEN2721'),
(3, 'Software Engineering II ', 'CEN3011'),
(3, 'Specifications of Software Systems ', 'CEN3016'),
(3, 'Software Design', 'CEN3064'),
(3, 'Software Testing', 'CEN3410'),
(3, 'Cloud & Internet Computing', 'CEN4086'),
(3, 'Domain Specific Languages', 'CEN4230'),
(3, 'Introduction to Computers', 'CGS1000C'),
(3, 'Management Information Systems', 'CGS3300'),
(4, 'Java Programming I', 'COP1800C'),
(4, 'Java Programming II', 'COP1805C'),
(4, 'C# (Sharp) Programming I ', 'COP2360C'),
(4, 'Web Systems ', 'COP2843C'),
(3, 'Operating Systems', 'COP3610'),
(3, 'Mobile Application Development', 'COP3650'),
(3, 'Compiler Construction', 'COP4620'),
(4, 'Introduction to Algorithms', 'COT1405'),
(4, 'Discrete Mathematics and Probability', 'COT2104'),
(3, 'Theory of Computation', 'COT3205'),
(4, 'Essentials of Networking', 'CTS1305C'),
(4, 'Multi-User Operating Systems ', 'CTS2106C'),
(3, 'English Composition I', 'ENC1101'),
(3, 'English Composition II', 'ENC2102'),
(3, 'Professional Writing', 'ENC3213'),
(1, 'Freshman Seminar', 'FRE1010'),
(3, 'Database Management Systems ', 'ISM4212'),
(3, 'College Algebra', 'MAC2105'),
(3, 'Project Management', 'MAN4583'),
(3, 'Philosophy of the Human Person', 'PHIL2050'),
(3, 'Introduction to Psychology', 'PSY1012'),
(3, 'Speech', 'SPC1017'),
(3, 'Statistics', 'STA2023'),
(3, 'Intermediate Statistics', 'STA3163');
