
-- --------------------------------------------------------

--
-- Table structure for table `interdisciplinary studies`
--

DROP TABLE IF EXISTS `interdisciplinary studies`;
CREATE TABLE IF NOT EXISTS `interdisciplinary studies` (
  `credits` tinyint(2) DEFAULT NULL,
  `coursename` varchar(75) DEFAULT NULL,
  `coursecode` varchar(15) NOT NULL,
  PRIMARY KEY (`coursecode`),
  UNIQUE KEY `coursecode` (`coursecode`),
  UNIQUE KEY `coursename` (`coursename`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `interdisciplinary studies`
--

INSERT INTO `interdisciplinary studies` (`credits`, `coursename`, `coursecode`) VALUES
(3, 'General Chemistry', 'CHM2045'),
(1, 'General Chemistry Lab', 'CHM2045L'),
(3, 'Advanced Chemistry', 'CHM2046'),
(1, 'Advanced Chemistry Lab', 'CHM2046L'),
(4, 'Java Programmng I', 'COP1800C'),
(4, 'Java Programing II', 'COP1805C'),
(3, 'Microeconomics', 'ECO1023'),
(3, 'Macroeconomics', 'ECO2013'),
(3, 'English Composition I', 'ENC1101'),
(3, 'English Composition II', 'ENC2102'),
(1, 'Freshman Seminar', 'FRE1010'),
(3, 'Pre-Calculus with Trigonometry', 'MAC2147'),
(3, 'Calculus', 'MAC2311'),
(3, 'Calculus II', 'MAC2422'),
(3, 'Differential Equations', 'MAC3252'),
(3, 'Linear Algebra', 'MAC3311'),
(3, 'Calculus III', 'MAC3422'),
(4, 'University Physics I', 'PHYS221'),
(0, 'University Physics I Lab ', 'PHYS221L'),
(4, 'University Physics II', 'PHYS222'),
(3, 'Statistics', 'STA2023');
