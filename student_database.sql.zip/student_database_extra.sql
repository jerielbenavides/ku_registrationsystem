
--
-- Constraints for dumped tables
--

--
-- Constraints for table `business administration`
--
ALTER TABLE `business administration`
  ADD CONSTRAINT `business administration_ibfk_1` FOREIGN KEY (`coursecode`) REFERENCES `all_courses` (`coursecode`) ON UPDATE CASCADE;

--
-- Constraints for table `courses_spring_2018`
--
ALTER TABLE `courses_spring_2018`
  ADD CONSTRAINT `courses_spring_2018_ibfk_1` FOREIGN KEY (`coursecode`) REFERENCES `all_courses` (`coursecode`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `courses_spring_2018_ibfk_2` FOREIGN KEY (`coursename`) REFERENCES `all_courses` (`coursename`);

--
-- Constraints for table `interdisciplinary studies`
--
ALTER TABLE `interdisciplinary studies`
  ADD CONSTRAINT `interdisciplinary studies_ibfk_1` FOREIGN KEY (`coursecode`) REFERENCES `all_courses` (`coursecode`) ON UPDATE CASCADE;

--
-- Constraints for table `management information systems`
--
ALTER TABLE `management information systems`
  ADD CONSTRAINT `management information systems_ibfk_1` FOREIGN KEY (`coursecode`) REFERENCES `all_courses` (`coursecode`) ON UPDATE CASCADE;

--
-- Constraints for table `political science`
--
ALTER TABLE `political science`
  ADD CONSTRAINT `political science_ibfk_1` FOREIGN KEY (`coursecode`) REFERENCES `all_courses` (`coursecode`) ON UPDATE CASCADE;

--
-- Constraints for table `psychology`
--
ALTER TABLE `psychology`
  ADD CONSTRAINT `psychology_ibfk_1` FOREIGN KEY (`coursecode`) REFERENCES `all_courses` (`coursecode`) ON UPDATE CASCADE;

--
-- Constraints for table `requirements`
--
ALTER TABLE `requirements`
  ADD CONSTRAINT `requirements_ibfk_1` FOREIGN KEY (`coursecode`) REFERENCES `all_courses` (`coursecode`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `requirements_ibfk_2` FOREIGN KEY (`requirement`) REFERENCES `all_courses` (`coursecode`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `software engineering`
--
ALTER TABLE `software engineering`
  ADD CONSTRAINT `coursecode_1[softeng]` FOREIGN KEY (`coursecode`) REFERENCES `all_courses` (`coursecode`),
  ADD CONSTRAINT `coursename_1[softeng]` FOREIGN KEY (`coursename`) REFERENCES `all_courses` (`coursename`);

--
-- Constraints for table `student_information`
--
ALTER TABLE `student_information`
  ADD CONSTRAINT `student_information_ibfk_1` FOREIGN KEY (`major`) REFERENCES `ku_majors` (`major_name`) ON DELETE SET NULL ON UPDATE CASCADE;
