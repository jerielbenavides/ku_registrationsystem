
-- --------------------------------------------------------

--
-- Table structure for table `ku_majors`
--

DROP TABLE IF EXISTS `ku_majors`;
CREATE TABLE IF NOT EXISTS `ku_majors` (
  `major_id` varchar(10) DEFAULT NULL,
  `major_name` varchar(70) DEFAULT NULL,
  UNIQUE KEY `major_name` (`major_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ku_majors`
--

INSERT INTO `ku_majors` (`major_id`, `major_name`) VALUES
('BSSE', 'Software Engineering'),
('BSMIS', 'Management Information Systems'),
('BSIS', 'Interdisciplinary Studies'),
('BABA', 'Business Administration'),
('BAPS', 'Political Science'),
('BAP', 'Psychology');
