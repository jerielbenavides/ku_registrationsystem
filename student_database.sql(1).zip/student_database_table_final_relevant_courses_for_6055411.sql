
-- --------------------------------------------------------

--
-- Table structure for table `final_relevant_courses_for_6055411`
--

DROP TABLE IF EXISTS `final_relevant_courses_for_6055411`;
CREATE TABLE IF NOT EXISTS `final_relevant_courses_for_6055411` (
  `courseid` int(11) NOT NULL DEFAULT '0',
  `coursecode` varchar(15) DEFAULT NULL,
  `coursename` varchar(75) NOT NULL DEFAULT '',
  `credits` tinyint(4) DEFAULT NULL,
  `timein` time DEFAULT NULL,
  `timeout` time DEFAULT NULL,
  `instructor` varchar(30) DEFAULT NULL,
  `room` varchar(15) DEFAULT NULL,
  `mode` varchar(15) DEFAULT NULL,
  `monday` bit(1) DEFAULT NULL,
  `tuesday` bit(1) DEFAULT NULL,
  `wednesday` bit(1) DEFAULT NULL,
  `thursday` bit(1) DEFAULT NULL,
  `friday` bit(1) DEFAULT NULL,
  `saturday` bit(1) DEFAULT NULL,
  `sunday` bit(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `final_relevant_courses_for_6055411`
--

INSERT INTO `final_relevant_courses_for_6055411` (`courseid`, `coursecode`, `coursename`, `credits`, `timein`, `timeout`, `instructor`, `room`, `mode`, `monday`, `tuesday`, `wednesday`, `thursday`, `friday`, `saturday`, `sunday`) VALUES
(5, 'COP2843C', 'Web Systems ', 4, '14:30:00', '15:35:00', 'Armando Paladino', NULL, 'Online', b'1', b'0', b'1', b'0', b'1', b'0', b'0'),
(7, 'CDA4125', 'Concepts of Parallel and Distributed Processing', 3, '08:00:00', '09:15:00', 'Andrew Harris', NULL, 'Online', b'0', b'1', b'0', b'1', b'0', b'0', b'0'),
(25, 'STA3163', 'Intermediate Statistics', 3, '13:00:00', '14:15:00', 'Erwin Kruger', 'SB116', 'On Campus', b'1', b'0', b'1', b'0', b'1', b'0', b'0'),
(27, 'STA3163', 'Intermediate Statistics', 3, '13:00:00', '14:15:00', 'Erwin Kruger', 'SB116', 'On Campus', b'1', b'0', b'1', b'0', b'1', b'0', b'0'),
(11, 'CGS1000C', 'Introduction to Computers', 3, '10:00:00', '10:50:00', 'Eduardo Orozco', 'COMPLAB', 'On Campus', b'1', b'0', b'1', b'0', b'1', b'0', b'0'),
(12, 'ENC1101', 'English Composition I', 3, '09:00:00', '09:50:00', 'First Last', 'E107', 'On Campus', b'1', b'0', b'1', b'0', b'1', b'0', b'0'),
(13, 'ENC1101', 'English Composition I', 3, '10:00:00', '10:50:00', 'First Last', 'E107', 'On Campus', b'1', b'0', b'1', b'0', b'1', b'0', b'0'),
(14, 'ENC1101', 'English Composition I', 3, '14:00:00', '14:50:00', 'First Last', 'E107', 'On Campus', b'1', b'0', b'1', b'0', b'1', b'0', b'0'),
(19, 'MAC2105', 'College Algebra', 3, '10:00:00', '10:50:00', 'Morales', 'C107', 'On Campus', b'1', b'0', b'1', b'0', b'1', b'0', b'0'),
(20, 'MAC2105', 'College Algebra', 3, '14:00:00', '14:50:00', 'Morales', 'C107', 'On Campus', b'1', b'0', b'1', b'0', b'1', b'0', b'0'),
(21, 'MAC2105', 'College Algebra', 3, '15:00:00', '14:15:00', 'Morales', 'C107', 'On Campus', b'0', b'1', b'0', b'1', b'0', b'0', b'0'),
(22, 'PHIL2050', 'Philosophy of the Human Person', 3, '10:00:00', '10:50:00', 'Mathew Anderson', NULL, 'Online', b'1', b'0', b'1', b'0', b'1', b'0', b'0');
