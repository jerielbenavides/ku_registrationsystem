
-- --------------------------------------------------------

--
-- Table structure for table `student_information`
--

DROP TABLE IF EXISTS `student_information`;
CREATE TABLE IF NOT EXISTS `student_information` (
  `ID` varchar(10) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `first` text,
  `middle` text,
  `last` text,
  `address` varchar(140) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `country` text,
  `city` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `zip` varchar(10) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `major` varchar(70) DEFAULT NULL,
  UNIQUE KEY `ID` (`ID`),
  UNIQUE KEY `username` (`username`),
  KEY `major` (`major`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_information`
--

INSERT INTO `student_information` (`ID`, `username`, `first`, `middle`, `last`, `address`, `phone`, `country`, `city`, `state`, `zip`, `birthdate`, `major`) VALUES
('6055411', 'J.Benavides', 'Jeriel', 'Manuel', 'Benavides', 'Somewhere', '+50584390546', 'Nicaragua', 'Estelí', 'Estelí', '31000', '1997-02-25', 'Software Engineering'),
('6055412', 'A.Gomez', 'Adonis', NULL, 'Gómez', 'Rivas', NULL, 'Nicaragua', 'Rivas', 'Rivas', '31456', '1996-05-04', 'Management Information Systems');
