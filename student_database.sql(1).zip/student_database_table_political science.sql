
-- --------------------------------------------------------

--
-- Table structure for table `political science`
--

DROP TABLE IF EXISTS `political science`;
CREATE TABLE IF NOT EXISTS `political science` (
  `credits` tinyint(2) DEFAULT NULL,
  `coursename` varchar(75) DEFAULT NULL,
  `coursecode` varchar(15) NOT NULL,
  PRIMARY KEY (`coursecode`),
  UNIQUE KEY `coursecode` (`coursecode`),
  UNIQUE KEY `coursename` (`coursename`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `political science`
--

INSERT INTO `political science` (`credits`, `coursename`, `coursecode`) VALUES
(3, 'American History Since 1876', 'AMH1020'),
(3, 'American Literature', 'AML1000'),
(3, 'Conflict Resolution', 'COM3465'),
(3, 'Introduction to Comparative Government and Politics', 'CPO2002'),
(3, 'Politics of the Developing World', 'CPO2030'),
(3, 'Domestic and International Terrorism', 'DSC1011'),
(3, 'The World Economy', 'ECO4701'),
(3, 'English Composition I', 'ENC1101'),
(3, 'English Composition II', 'ENC2102'),
(3, 'Freshman Seminar', 'FRE1010'),
(3, 'History of Civil Rights and Civil Liberties', 'HIS3319'),
(3, 'Critical Thinking', 'IDS3355'),
(3, 'International Relations', 'INR2001'),
(3, 'US Latin American Relations', 'INR2109'),
(3, 'Middle East Foreign Policy', 'INR3274'),
(3, 'College Algebra ', 'MAC2105'),
(3, 'College Mathematics', 'MGF2106'),
(3, 'Intro to Public Policy', 'PAD3034'),
(3, 'Public Finance', 'PAD4204'),
(3, 'Philosophy of the Human Person', 'PHIL2050'),
(3, 'Aesthetics/Philosophy of Art ', 'PHIL3800'),
(3, 'Criminal Law', 'PLA1304'),
(3, 'Immigration Law', 'PLA4844'),
(3, 'American Constitutional Law', 'PLA4880 '),
(3, 'Political Science', 'POS1041'),
(3, 'Intergovernmental Relations', 'POS3063'),
(3, 'Voting Behavior and Public Opinion', 'POS3205'),
(3, 'Mass Media and Politics', 'POS3235'),
(3, 'The Campaign Process', 'POS3274'),
(3, 'The American Presidency', 'POS3413'),
(3, 'Environmental Politics', 'POS4035'),
(3, 'Urban Government Social Policy', 'POS4142'),
(3, 'Intro to Political Theory', 'POT1003'),
(3, 'Great Political Thinkers', 'POT3044'),
(3, 'Religion and Politics', 'POT3632 '),
(3, 'Introduction to Psychology', 'PSY1012'),
(3, 'Issues in International Policy', 'PUP4052'),
(3, 'Speech Communication', 'SPC1017'),
(3, 'Statistics', 'STA2023'),
(3, 'Intermediate Statistics', 'STA3163'),
(3, 'Sacred Scriptures', 'THEO1050'),
(3, 'Introduction to Catholicism', 'THEO1051');
