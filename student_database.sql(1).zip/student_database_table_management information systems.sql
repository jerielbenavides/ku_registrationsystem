
-- --------------------------------------------------------

--
-- Table structure for table `management information systems`
--

DROP TABLE IF EXISTS `management information systems`;
CREATE TABLE IF NOT EXISTS `management information systems` (
  `credits` tinyint(2) DEFAULT NULL,
  `coursename` varchar(75) DEFAULT NULL,
  `coursecode` varchar(15) NOT NULL,
  PRIMARY KEY (`coursecode`),
  UNIQUE KEY `coursecode` (`coursecode`),
  UNIQUE KEY `coursename` (`coursename`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `management information systems`
--

INSERT INTO `management information systems` (`credits`, `coursename`, `coursecode`) VALUES
(3, 'Accounting Principles I', 'ACG1001'),
(3, 'Accounting Principles II', 'ACG2011'),
(3, 'American History Since 1877', 'AMH1020'),
(3, 'Business Law', 'BUL1240'),
(3, 'Legal and Ethical Environ of Business', 'BUL3130'),
(3, 'Introduction to Computers', 'CGS1000C'),
(3, 'Management Information Systems', 'CGS3300'),
(3, 'Computer Operating Systems', 'CTS3107C'),
(3, 'Computer Architecture Concepts', 'CTS3135'),
(3, 'English Composition I', 'ENC1101'),
(3, 'English Composition II', 'ENC2102'),
(3, 'Professional Writing', 'ENC3213'),
(3, 'Financial Management', 'FIN2001'),
(1, 'Freshman Seminar', 'FRE1010'),
(3, 'Entrepreneurship', 'GEB1112'),
(3, 'Critical Thinking', 'IDS3355'),
(3, 'Industrial Psychology', 'INP3004'),
(3, 'Systems Analysis', 'ISM3112'),
(3, 'Data Communications and Networking', 'ISM3221'),
(3, 'Intro to Business Programming', 'ISM3230'),
(3, 'Advanced Business Appl Development', 'ISM3232'),
(3, 'Systems Design', 'ISM4113 '),
(3, 'Info Systems Implementation', 'ISM4130'),
(3, 'Database Management Systems', 'ISM4212'),
(3, 'Distributed Information Systems', 'ISM4220'),
(3, 'Info Technology Management', 'ISM4300'),
(3, ' College Algebra', 'MAC2105'),
(3, 'Principles of Management', 'MAN1021'),
(3, 'Human Resources Mgt', 'MAN2300'),
(3, 'Introduction to Mgt/Org Behavior', 'MAN3025'),
(3, 'Operations Management', 'MAN3504 '),
(3, 'Project Management', 'MAN4583'),
(3, 'International Business', 'MAN4602'),
(3, 'Introduction to Marketing', 'MAR1011'),
(3, 'College Mathematics', 'MGF2106'),
(3, 'Philosophy of the Human Person', 'PHIL2050'),
(3, 'Aesthetics/Philosophy of Arts', 'PHIL3800'),
(3, 'Introduction to Psychology', 'PSY1012'),
(3, 'Speech', 'SPC1017'),
(3, 'Statistics', 'STA2023'),
(3, 'Intermediate Statistics', 'STA3163'),
(3, 'Sacred Scriptures', 'THEO1050'),
(3, 'Introduction to Catholicism', 'THEO1051');
