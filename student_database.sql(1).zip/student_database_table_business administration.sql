
-- --------------------------------------------------------

--
-- Table structure for table `business administration`
--

DROP TABLE IF EXISTS `business administration`;
CREATE TABLE IF NOT EXISTS `business administration` (
  `credits` tinyint(2) NOT NULL,
  `coursename` varchar(75) DEFAULT NULL,
  `coursecode` varchar(15) NOT NULL,
  `minorID` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`coursecode`),
  UNIQUE KEY `coursecode` (`coursecode`),
  UNIQUE KEY `coursename` (`coursename`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `business administration`
--

INSERT INTO `business administration` (`credits`, `coursename`, `coursecode`, `minorID`) VALUES
(3, 'Accounting Principles I', 'ACG1001', NULL),
(3, 'Accounting Principles II', 'ACG2011', NULL),
(3, 'Managerial Accounting', 'ACG3073', NULL),
(3, 'American History Since 1876', 'AMH1020', NULL),
(3, 'Business law', 'BUL1240', NULL),
(3, 'Legal/Ethical Environment of Bus', 'BUL3130', NULL),
(3, ' Introduction to Computers', 'CGS1000C', NULL),
(3, 'Management Information Systems', 'CGS3300', NULL),
(3, 'Money and Banking', 'ECO4223', NULL),
(3, 'English Composition I', 'ENC1101', NULL),
(3, 'English Composition II', 'ENC2102', NULL),
(3, 'Professional Writing', 'ENC3213', NULL),
(3, 'Financial Management', 'FIN2001', NULL),
(3, 'Principles of Managerial Finance', 'FIN3400', NULL),
(3, 'Financial Decision-Making-Planning', 'FIN4126', NULL),
(3, 'Commercial Bank Management', 'FIN4324', NULL),
(3, 'Case Studies in Finance', 'FIN4424', NULL),
(3, 'Financial Policy and Strategy', 'FIN4443', NULL),
(3, 'Investment', 'FIN4501', NULL),
(3, 'International Finance', 'FIN4602', NULL),
(3, 'Freshman Seminar', 'FRE1010', NULL),
(3, 'Entrepreneurship', 'GEB1112', NULL),
(3, 'International Competitiveness', 'GEB4357', NULL),
(3, 'International Negotiations and Transactions', 'GEB4358', NULL),
(3, 'Cultural Environment of International Business', 'GEB4359', NULL),
(3, 'International Entrepreneurship', 'GEB4364', NULL),
(3, 'Critical Thinking', 'IDS3355', NULL),
(3, 'College Algebra ', 'MAC2105', NULL),
(3, 'Principles of Management', 'MAN1021', NULL),
(3, 'Human Resources Management', 'MAN2300', NULL),
(3, 'Introduction to Mgt/Org Behavior', 'MAN3025', NULL),
(3, 'Industrial/Organizational Psychology ', 'MAN3326', NULL),
(3, 'Operations Management', 'MAN3504', NULL),
(3, 'Cross-Cultural Management', 'MAN3611', NULL),
(3, 'Business Ethics', 'MAN4065', NULL),
(3, 'Managing Diversity', 'MAN4113', NULL),
(3, 'Leadership', 'MAN4164', NULL),
(3, 'Performance Management', 'MAN4337', NULL),
(3, 'Project Management', 'MAN4583', NULL),
(3, 'International Business', 'MAN4602', NULL),
(3, 'Global Strategy and Policy', 'MAN4631', NULL),
(3, 'Integrated Capstone Course', 'MAN4999', NULL),
(3, 'Introduction to Marketing', 'MAR1011', NULL),
(3, 'Advertising/Promotion Management', 'MAR4334', NULL),
(3, 'Sales and Sales Management', 'MAR4403', NULL),
(3, 'Consumer Behavior', 'MAR4503', NULL),
(3, 'E-Marketing', 'MAR4721', NULL),
(3, 'Marketing Strategy', 'MAR4804', NULL),
(3, 'Service Marketing', 'MAR4841', NULL),
(3, 'College Mathematics', 'MGF2106', NULL),
(3, 'Recruitment, Selection and Staffing', 'MNA3324', NULL),
(3, 'Training and Development', 'MNA4306', NULL),
(3, 'Mgt Law and Employee Relations', 'MNA4404', NULL),
(3, 'Labor Relations', 'MNA4405', NULL),
(3, 'Philosophy of the Human Person', 'PHIL2050', NULL),
(3, 'Aesthetics/Philosophy of Arts', 'PHIL3800', NULL),
(3, 'Introduction to Psychology', 'PSY1012', NULL),
(3, 'Quantitative Approach of Business', 'QMB3200', NULL),
(3, 'Speech Communication', 'SPC1017', NULL),
(3, 'Statistics', 'STA2023', NULL),
(3, 'Intermediate Statistics', 'STA3163', NULL),
(3, 'Sacred Scriptures', 'THEO1050', NULL),
(3, 'Introduction to Catholicism', 'THEO1051', NULL);
