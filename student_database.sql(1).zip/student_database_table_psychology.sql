
-- --------------------------------------------------------

--
-- Table structure for table `psychology`
--

DROP TABLE IF EXISTS `psychology`;
CREATE TABLE IF NOT EXISTS `psychology` (
  `credits` tinyint(2) DEFAULT NULL,
  `coursename` varchar(75) DEFAULT NULL,
  `coursecode` varchar(15) NOT NULL,
  PRIMARY KEY (`coursecode`),
  UNIQUE KEY `coursecode` (`coursecode`),
  UNIQUE KEY `coursename` (`coursename`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `psychology`
--

INSERT INTO `psychology` (`credits`, `coursename`, `coursecode`) VALUES
(3, 'General Biology', 'BSC1010 '),
(3, 'Legal/Ethical Environment of Bus', 'BUL3130'),
(3, 'Addictive Behaviors', 'CLP 4182 '),
(3, 'Marriage and Family', 'CLP3005'),
(3, 'Concepts of Clinical and Counseling Psychology', 'CLP3300'),
(3, 'Health Psychology', 'CLP3314'),
(3, 'Forensic Psychology', 'CLP4390'),
(3, 'Interpersonal Communication', 'COM3131'),
(3, 'Introduction to Cognitive Development', 'DEP1030'),
(3, 'Human Exceptionality', 'DEP2280'),
(3, 'Child Psychology', 'DEP3103'),
(3, 'Adolescent Psychology  ', 'DEP4305'),
(3, ' Psychology of Adult Development and Aging', 'DEP4404'),
(3, 'Death and Dying', 'DEP4481'),
(3, 'English Composition I', 'ENC1101'),
(3, 'English Composition II', 'ENC2102'),
(3, 'Principles of Learning', 'EXP3404'),
(3, 'Freshman Seminar', 'FRE1010'),
(3, 'Critical Thinking', 'IDS3355'),
(3, 'Workforce Diversity', 'INP3224'),
(3, 'College Algebra ', 'MAC2105'),
(3, 'College Mathematics', 'MGF2106'),
(3, 'Philosophy of the Human Person', 'PHIL2050'),
(3, 'Aesthetics/Philosophy of Arts', 'PHIL3800'),
(3, 'Introduction to Psychology', 'PSY1012'),
(3, 'Introduction to Experimental Psychology', 'PSY1082'),
(3, 'Careers and Writing in Psychology', 'PSY2023'),
(3, 'Social Psychology', 'PSY2206'),
(3, 'Abnormal Psychology', 'PSY2214 '),
(3, 'Psychology of Personality', 'PSY2314 '),
(3, 'Construct of Interpersonal Conflict', 'PSY2450'),
(3, 'Research Methods', 'PSY3213'),
(3, 'Behavioral Neuroscience', 'PSY3309 '),
(3, 'Industrial and Organizational Psychology', 'PSY3336 '),
(3, 'Theory, Application, and Evaluation of Tests', 'PSY4302 '),
(3, 'Sports Psychology', 'PSY4830 '),
(3, 'Positive Psychology', 'PSY4850 '),
(3, 'Effective Spanish', 'SPAN113'),
(3, 'Statistics', 'STA2023'),
(3, 'Intermediate Statistics', 'STA3163'),
(3, 'Sacred Scriptures', 'THEO1050'),
(3, 'Introduction to Catholicism', 'THEO1051');
